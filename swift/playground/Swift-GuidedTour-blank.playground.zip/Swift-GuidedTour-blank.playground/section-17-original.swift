shoppingList = []
occupations = [:]
